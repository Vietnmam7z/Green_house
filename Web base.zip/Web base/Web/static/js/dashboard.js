// dashboard.js
async function capNhatDuLieu() {
    const response = await fetch('/api/data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ field_id: "field_999" })
    });

    const data = await response.json();
    console.log("Dữ liệu nhận được:", data);

    document.getElementById('telemetry-list').textContent = JSON.stringify(data, null, 2);
}

async function layDanhSachField() {
    try {
        const response = await fetch('/api/fields', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();
        console.log("Danh sách field:", data);

        // Hiển thị ra giao diện
        const fieldContainer = document.getElementById('field-list');
        if (fieldContainer) {
            fieldContainer.innerHTML = "";
            data.forEach(field => {
                const li = document.createElement('li');
                // dùng đúng key field_name
                li.textContent = field.field_name; 
                fieldContainer.appendChild(li);
            });
        }
    } catch (err) {
        console.error("Lỗi khi gọi API get_field:", err);
    }
}

// Gọi ngay khi tải trang
layDanhSachField();

// Lặp lại mỗi 5 giây
setInterval(layDanhSachField, 5000);
// Gọi ngay khi tải trang
capNhatDuLieu();
// Lặp lại mỗi 5 giây
setInterval(capNhatDuLieu, 5000);